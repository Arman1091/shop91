from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from . import views
from .forms import LoginForm, MyPasswordResetForm, MyPasswordChangeForm, MySetPasswordForm
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('complete-profile/', views.complete_profile, name="complete_profile"),
    path('', views.home, name="home"),
    path('categories/', views.all_categories, name='all_categories'),
    path('test/', views.test, name="test"),
    path('test2/', views.test2, name="test2"),
    path('<slug:category_slug>-<int:product_id>/editeur/', views.editeur, name='editeur'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('registration/', views.CustomerRegistrationView.as_view(), name="customerregistration"),
    path('login/', views.CustomLoginView.as_view(template_name="registrations/login.html", authentication_form=LoginForm), name="login"),
    path('passwordchange/', auth_views.PasswordChangeView.as_view(template_name="registrations/changepassword.html", form_class=MyPasswordChangeForm, success_url='/passwordchangedone'), name="passwordchange"),
    path('passwordchangedone/', auth_views.PasswordChangeDoneView.as_view(template_name="registrations/passwordchangedone.html"), name="passwordchangedone"),
    path('logout/', views.logout_view, name='logout'),
    path('password-reset/', auth_views.PasswordResetView.as_view(template_name="registrations/password_reset.html", form_class=MyPasswordResetForm), name="password_reset"),
    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(template_name="registrations/password_reset_done.html"), name="password_reset_done"),
    path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name="registrations/password_reset_confirm.html", form_class=MySetPasswordForm), name="password_reset_confirm"),
    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name="registrations/password_reset_complete.html"), name="password_reset_complete"),
    path("customize/<int:product_id>/", views.customize_product, name="customize_product"),
    path("customization-success/<int:customized_product_id>/", views.customization_success, name="customization_success"),
    path("wishlist/add/<int:customized_product_id>/", views.add_to_wishlist, name="add_to_wishlist"),
    path("wishlist/", views.view_wishlist, name="view_wishlist"),
    path("customization-success-temp/", views.customization_success_temp, name="customization_success_temp"),
    path("cookie-policy/", views.cookie_policy, name="cookie_policy"),
    path("set-cookie-consent/", views.set_cookie_consent, name="set_cookie_consent"),
    
    # Inclusion des URLs des nouvelles applications
    path('cart/', include('cart.urls')),
    path('payment/', include('payment.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)