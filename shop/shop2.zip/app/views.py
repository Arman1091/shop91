from django.shortcuts import render, get_object_or_404, redirect, HttpResponseRedirect
from django.contrib.auth import views as auth_views
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views import View
from django.urls import reverse, reverse_lazy
from django.contrib import messages
from .models import Customer, Category, SubCategory, Activity, Product, Material, PlaqueColor, TextColor, Police, CustomizedProduct, CustomizedLigneTexte, CustomizedStyleTexte, Wishlist, Address, CookieConsent
from cart.models import Cart, CartItem
from payment.models import Payment
from .forms import CustomerRegistrationForm, CustomerProfileForm, LoginForm, MyPasswordResetForm, MyPasswordChangeForm, MySetPasswordForm
import re
from django.conf import settings

# Vues existantes
def get_cookie_consent(request):
    if request.user.is_authenticated:
        try:
            return request.user.cookie_consent.accepted
        except CookieConsent.DoesNotExist:
            return False  # Par défaut, refusé si pas encore défini
    else:
        return request.COOKIES.get('cookie_consent', 'declined') == 'accepted'

@login_required
def complete_profile(request):
    customer, created = Customer.objects.get_or_create(user=request.user)
    if customer.is_profile_complete:
        return redirect('home')

    if request.method == "POST":
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            customer.mobile = form.cleaned_data['mobile']
            address = Address(
                street_address=form.cleaned_data['street_address'],
                complement_address=form.cleaned_data['complement_address'],
                city=form.cleaned_data['city'],
                postal_code=form.cleaned_data['postal_code'],
                country=form.cleaned_data['country'],
            )
            address.save()
            customer.address = address
            customer.is_profile_complete = True
            customer.save()
            return redirect('home')
    else:
        initial_data = {
            'mobile': customer.mobile,
            'street_address': customer.address.street_address if customer.address else '',
            'complement_address': customer.address.complement_address if customer.address else '',
            'city': customer.address.city if customer.address else '',
            'postal_code': customer.address.postal_code if customer.address else '',
            'country': customer.address.country if customer.address else '',
        }
        form = CustomerProfileForm(initial=initial_data)

    return render(request, "pages/complete_profile.html", {'form': form})

def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse('login'))

class CustomLoginView(auth_views.LoginView):
    template_name = "registrations/login.html"
    authentication_form = LoginForm

    def form_valid(self, form):
        response = super().form_valid(form)
        merge_session_with_user(self.request)
        return response

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("home")
        return super().dispatch(request, *args, **kwargs)

class CustomerRegistrationView(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'registrations/customerregistration.html', {'form': form})

    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Congratulations! User Register Successfully")
        else:
            messages.warning(request, "Invalid Input Data")
        return render(request, 'registrations/customerregistration.html', {'form': form})

def home(request):
    category_plaque_prof = Category.objects.filter(slug_name="plaque-professionnelle").first()
    category_plaque_maison = Category.objects.filter(slug_name="plaque-pour-la-maison").first()
    plaque_prof_products = Product.objects.filter(activity__sub_category__category=category_plaque_prof, is_first_vu=True) if category_plaque_prof else Product.objects.none()
    plaque_maison_products = Product.objects.filter(activity__sub_category__category=category_plaque_maison, is_first_vu=True) if category_plaque_maison else Product.objects.none()
    return render(request, "pages/home.html", {'plaque_prof_products': plaque_prof_products, 'plaque_maison_products': plaque_maison_products})

def test(request):
    return render(request, "pages/test.html")

def test2(request):
    return render(request, "pages/test2.html")

def all_categories(request):
    categories = Category.objects.all()
    for category in categories:
        category.has_subcategories = category.subcategories.exists()
    return render(request, "pages/categories.html", {"categories": categories})

def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'editeur/editeur.html', {'product': product})

def editeur(request, category_slug, product_id):
    category = get_object_or_404(Category, slug_name=category_slug)
    product = get_object_or_404(Product, id=product_id, activity__sub_category__category=category)
    materials = Material.objects.all()
    return render(request, 'editeur/editeur.html', {'product': product, 'all_categories': all_categories, "materials": materials})

def customize_product(request, product_id):
    base_product = get_object_or_404(Product, id=product_id)
    materials = Material.objects.all()
    plaque_colors = PlaqueColor.objects.all()

    if request.method == "POST":
        customization_data = {
            "base_product_id": base_product.id,
            "material_id": request.POST.get("material"),
            "plaque_color_id": request.POST.get("plaque_color"),
            "logo": request.FILES.get("logo"),
            "logo_width": request.POST.get("logo_width"),
            "logo_height": request.POST.get("logo_height"),
            "logo_position_x": request.POST.get("logo_position_x"),
            "logo_position_y": request.POST.get("logo_position_y"),
            "qrCode": request.FILES.get("qrCode"),
            "qrCode_width": request.POST.get("qrCode_width"),
            "qrCode_height": request.POST.get("qrCode_height"),
            "qrCode_position_x": request.POST.get("qrCode_position_x"),
            "qrCode_position_y": request.POST.get("qrCode_position_y"),
            "textes": request.POST.getlist("texte[]"),
            "tailles": request.POST.getlist("taille_police[]"),
            "hidden_textes": request.POST.getlist("hidden_texte[]"),
        }

        if request.user.is_authenticated:
            customized_product = CustomizedProduct(
                user=request.user,
                base_product=base_product,
                material_id=customization_data["material_id"],
                plaque_color_id=customization_data["plaque_color_id"],
                logo=customization_data["logo"],
                logo_width=customization_data["logo_width"],
                logo_height=customization_data["logo_height"],
                logo_position_x=customization_data["logo_position_x"],
                logo_position_y=customization_data["logo_position_y"],
                qrCode=customization_data["qrCode"],
                qrCode_width=customization_data["qrCode_width"],
                qrCode_height=customization_data["qrCode_height"],
                qrCode_position_x=customization_data["qrCode_position_x"],
                qrCode_position_y=customization_data["qrCode_position_y"],
            )
            customized_product.save()

            textes = customization_data["textes"]
            tailles = customization_data["tailles"]
            hidden_textes = customization_data["hidden_textes"]

            for i, texte in enumerate(textes):
                if texte:
                    hidden_style = hidden_textes[i] if i < len(hidden_textes) else ""
                    style_dict = {
                        "font-size": re.search(r"font-size:\s*(\d+)px", hidden_style),
                        "color": re.search(r"color:\s*(#[0-9a-fA-F]{6})", hidden_style),
                        "font-weight": re.search(r"font-weight:\s*bold", hidden_style),
                        "font-style": re.search(r"font-style:\s*italic", hidden_style),
                        "text-decoration": re.search(r"text-decoration:\s*underline", hidden_style),
                        "font-family": re.search(r"font-family:\s*([^;]+)", hidden_style),
                        "left": re.search(r"left:\s*(\d+)px", hidden_style),
                        "top": re.search(r"top:\s*(\d+)px", hidden_style),
                    }

                    style = CustomizedStyleTexte.objects.create(
                        gras=bool(style_dict["font-weight"]),
                        italique=bool(style_dict["font-style"]),
                        souligne=bool(style_dict["text-decoration"]),
                        couleur=style_dict["color"].group(1) if style_dict["color"] else "#000000",
                    )

                    CustomizedLigneTexte.objects.create(
                        customized_product=customized_product,
                        texte=texte,
                        police=Police.objects.filter(nom=style_dict["font-family"].group(1)).first() if style_dict["font-family"] else Police.objects.first(),
                        taille_police=tailles[i] if i < len(tailles) else (int(style_dict["font-size"].group(1)) if style_dict["font-size"] else 14),
                        position_x=int(style_dict["left"].group(1)) if style_dict["left"] else 0,
                        position_y=int(style_dict["top"].group(1)) if style_dict["top"] else i * 20,
                        style=style
                    )

            return redirect("customization_success", customized_product_id=customized_product.id)
        else:
            if "pending_customizations" not in request.session:
                request.session["pending_customizations"] = []
            customization_id = len(request.session["pending_customizations"])
            customization_data["temp_id"] = customization_id
            request.session["pending_customizations"].append(customization_data)
            request.session.modified = True
            return redirect("customization_success", customized_product_id=customization_id)

    return render(request, "pages/customize_product.html", {
        "product": base_product,
        "materials": materials,
        "plaque_colors": plaque_colors,
    })

def customization_success_temp(request):
    return render(request, "pages/customization_success_temp.html")

def customization_success(request, customized_product_id):
    if request.user.is_authenticated:
        customized_product = get_object_or_404(CustomizedProduct, id=customized_product_id)
    else:
        pending_customizations = request.session.get("pending_customizations", [])
        customized_product = None
        try:
            customized_product_id_int = int(customized_product_id)
            for item in pending_customizations:
                item_id = item.get("temp_id", None)
                if item_id is not None and item_id == customized_product_id_int:
                    customized_product = item
                    break
            if not customized_product:
                customized_product = pending_customizations[customized_product_id_int] if customized_product_id_int < len(pending_customizations) else None
        except (ValueError, IndexError):
            messages.error(request, "Personnalisation introuvable.")
            return redirect('home')

        if not customized_product:
            messages.error(request, "Personnalisation introuvable.")
            return redirect('home')

    return render(request, "pages/customization_success.html", {
        "customized_product": customized_product,
        "customized_product_id": customized_product_id,
        "is_authenticated": request.user.is_authenticated
    })
def add_to_wishlist(request, customized_product_id):
    customized_product = get_object_or_404(CustomizedProduct, id=customized_product_id)
    if request.user.is_authenticated:
        wishlist_item, created = Wishlist.objects.get_or_create(user=request.user, customized_product=customized_product)
        if created:
            return JsonResponse({"message": "Ajouté à la wishlist !"})
        return JsonResponse({"message": "Déjà dans la wishlist."})
    else:
        if "wishlist" not in request.session:
            request.session["wishlist"] = []
        wishlist = request.session["wishlist"]
        if customized_product_id not in wishlist:
            wishlist.append(customized_product_id)
            request.session["wishlist"] = wishlist
            return JsonResponse({"message": "Ajouté à la wishlist (session) !"})
        return JsonResponse({"message": "Déjà dans la wishlist (session)."})

def view_wishlist(request):
    cookie_consent = request.user.cookie_consent.accepted if request.user.is_authenticated else (request.COOKIES.get('cookie_consent', 'declined') == 'accepted')
    if not cookie_consent:
        return JsonResponse({"message": "Veuillez accepter les cookies pour ajouter au panier."}, status=403)
    if request.user.is_authenticated:
        wishlist_items = Wishlist.objects.filter(user=request.user)
        return render(request, "pages/wishlist.html", {"wishlist_items": wishlist_items, "is_authenticated": True})
    else:
        wishlist = request.session.get("wishlist", [])
        wishlist_items = []
        for product_id in wishlist:
            customized_product = get_object_or_404(CustomizedProduct, id=product_id)
            wishlist_items.append({"customized_product": customized_product})
        return render(request, "pages/wishlist.html", {"wishlist_items": wishlist_items, "is_authenticated": False})

def merge_session_with_user(request):
    if not request.user.is_authenticated:
        return
    cookie_consent = request.COOKIES.get('cookie_consent', 'declined') == 'accepted'
    if cookie_consent:
        CookieConsent.objects.update_or_create(
            user=request.user,
            defaults={"accepted": True}
        )
    pending_customizations = request.session.get("pending_customizations", [])
    temp_id_to_product = {}
    for customization_data in pending_customizations:
        customized_product = CustomizedProduct(
            user=request.user,
            base_product=get_object_or_404(Product, id=customization_data["base_product_id"]),
            material_id=customization_data["material_id"],
            plaque_color_id=customization_data["plaque_color_id"],
            logo=customization_data["logo"],
            logo_width=customization_data["logo_width"],
            logo_height=customization_data["logo_height"],
            logo_position_x=customization_data["logo_position_x"],
            logo_position_y=customization_data["logo_position_y"],
            qrCode=customization_data["qrCode"],
            qrCode_width=customization_data["qrCode_width"],
            qrCode_height=customization_data["qrCode_height"],
            qrCode_position_x=customization_data["qrCode_position_x"],
            qrCode_position_y=customization_data["qrCode_position_y"],
        )
        customized_product.save()

        temp_id = customization_data.get("temp_id")
        if temp_id is not None:
            temp_id_to_product[temp_id] = customized_product

        textes = customization_data["textes"]
        tailles = customization_data["tailles"]
        hidden_textes = customization_data["hidden_textes"]

        for i, texte in enumerate(textes):
            if texte:
                hidden_style = hidden_textes[i] if i < len(hidden_textes) else ""
                style_dict = {
                    "font-size": re.search(r"font-size:\s*(\d+)px", hidden_style),
                    "color": re.search(r"color:\s*(#[0-9a-fA-F]{6})", hidden_style),
                    "font-weight": re.search(r"font-weight:\s*bold", hidden_style),
                    "font-style": re.search(r"font-style:\s*italic", hidden_style),
                    "text-decoration": re.search(r"text-decoration:\s*underline", hidden_style),
                    "font-family": re.search(r"font-family:\s*([^;]+)", hidden_style),
                    "left": re.search(r"left:\s*(\d+)px", hidden_style),
                    "top": re.search(r"top:\s*(\d+)px", hidden_style),
                }

                style = CustomizedStyleTexte.objects.create(
                    gras=bool(style_dict["font-weight"]),
                    italique=bool(style_dict["font-style"]),
                    souligne=bool(style_dict["text-decoration"]),
                    couleur=style_dict["color"].group(1) if style_dict["color"] else "#000000",
                )

                CustomizedLigneTexte.objects.create(
                    customized_product=customized_product,
                    texte=texte,
                    police=Police.objects.filter(nom=style_dict["font-family"].group(1)).first() if style_dict["font-family"] else Police.objects.first(),
                    taille_police=tailles[i] if i < len(tailles) else (int(style_dict["font-size"].group(1)) if style_dict["font-size"] else 14),
                    position_x=int(style_dict["left"].group(1)) if style_dict["left"] else 0,
                    position_y=int(style_dict["top"].group(1)) if style_dict["top"] else i * 20,
                    style=style
                )

    if "pending_customizations" in request.session:
        del request.session["pending_customizations"]

    session_wishlist = request.session.get("wishlist", [])
    for product_id in session_wishlist:
        try:
            product_id_int = int(product_id)
            customized_product = temp_id_to_product.get(product_id_int)
            if customized_product:
                Wishlist.objects.get_or_create(user=request.user, customized_product=customized_product)
            else:
                customized_product = get_object_or_404(CustomizedProduct, id=product_id_int)
                if not customized_product.user:
                    customized_product.user = request.user
                    customized_product.save()
                Wishlist.objects.get_or_create(user=request.user, customized_product=customized_product)
        except ValueError:
            pass

    if "wishlist" in request.session:
        del request.session["wishlist"]

    session_cart = request.session.get("cart", {})
    cart, created = Cart.objects.get_or_create(user=request.user, is_active=True)
    for product_id, quantity in session_cart.items():
        try:
            product_id_int = int(product_id)
            customized_product = temp_id_to_product.get(product_id_int)
            if customized_product:
                cart_item, item_created = CartItem.objects.get_or_create(cart=cart, customized_product=customized_product)
                if not item_created:
                    cart_item.quantity += quantity
                else:
                    cart_item.quantity = quantity
                cart_item.save()
            else:
                customized_product = get_object_or_404(CustomizedProduct, id=product_id_int)
                if not customized_product.user:
                    customized_product.user = request.user
                    customized_product.save()
                cart_item, item_created = CartItem.objects.get_or_create(cart=cart, customized_product=customized_product)
                if not item_created:
                    cart_item.quantity += quantity
                else:
                    cart_item.quantity = quantity
                cart_item.save()
        except ValueError:
            pass

    if "cart" in request.session:
        del request.session["cart"]

def set_cookie_consent(request):
    if request.method == "POST":
        consent = request.POST.get("consent") == "accept"
        if request.user.is_authenticated:
            CookieConsent.objects.update_or_create(
                user=request.user,
                defaults={"accepted": consent}
            )
            response = JsonResponse({"message": "Consentement enregistré en base"})
        else:
            response = JsonResponse({"message": "Consentement enregistré dans un cookie"})
            response.set_cookie(
                "cookie_consent",
                "accepted" if consent else "declined",
                max_age=31536000
            )
        return response
    return JsonResponse({"message": "Requête invalide"}, status=400)

def cookie_policy(request):
    return render(request, "pages/cookie_policy.html")
