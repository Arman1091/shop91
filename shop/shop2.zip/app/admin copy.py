from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from django import forms
from .models import (
    Address, Customer, Category, SubCategory, Activity, Material,
    Thickness, MaterialThicknessPrice, PlaqueColor, TextColor,
    Product, ProductImage, PlaqueCustomization, Order
)

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ('street_address', 'city', 'state', 'postal_code', 'country')
    search_fields = ('street_address', 'city', 'postal_code')

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('user', 'address', 'created_at')
    search_fields = ('user__username', 'address__city')

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug_name', 'image', 'image_preview','alt_text', )
    list_editable = ('image','alt_text', )  # Maintenant `image` est dans `list_display`
    fields = ('name', 'slug_name',  'image','alt_text',  'image_preview')
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="100" height="100" style="object-fit: cover; border-radius: 5px;" />', obj.image.url)
        return "Pas d'image"

    image_preview.short_description = "Aperçu"

    image_preview.short_description = "Aperçu"

@admin.register(SubCategory)
class SubCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'image','alt_text',  'image_preview')
    prepopulated_fields = {'slug_name': ('name',)}
    list_filter = ('category',)
    list_editable = ('image','alt_text')
    fields = ('name', 'slug_name', 'category', 'image','alt_text',  'image_preview')
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="100" height="100" style="object-fit: cover; border-radius: 5px;" />', obj.image.url)
        return "Pas d'image"

@admin.register(Activity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ('name', 'sub_category', 'fixed_price','image', 'alt_text', 'image_preview')
    prepopulated_fields = {'slug_name': ('name',)}
    list_filter = ('sub_category',)
    list_editable = ('image', 'alt_text')
    fields = ('name', 'slug_name', 'sub_category', 'image', 'alt_text', 'image_preview')
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="100" height="100" style="object-fit: cover; border-radius: 5px;" />', obj.image.url)
        return "Pas d'image"

    image_preview.short_description = "Aperçu"

@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'image_preview', 'alt_text')  # Affiche tous les champs
    list_editable = ('name', 'description', 'alt_text')  # Permet d'éditer directement ces champs
    list_display_links = None  # Désactive les liens pour que 'name' soit éditable

    def image_preview(self, obj):
        """Affiche un aperçu de l'image dans l'admin."""
        if obj.image:
            return format_html('<img src="{}" width="50" height="50" style="border-radius: 5px;" />', obj.image.url)
        return "(Aucune image)"

    image_preview.short_description = "Aperçu"  # Titre de la colonne

    # Ajout du champ image dans le formulaire d'édition complet
    fields = ('name', 'description', 'image', 'alt_text')
    search_fields = ('name', 'description')  # Ajoute une barre de recherche
    list_filter = ('name',)  # Filtrage possible

@admin.register(Thickness)
class ThicknessAdmin(admin.ModelAdmin):
    list_display = ('value', 'unit')

@admin.register(MaterialThicknessPrice)
class MaterialThicknessPriceAdmin(admin.ModelAdmin):
    list_display = ('material', 'thickness', 'price_per_square_meter')
    list_filter = ('material', 'thickness')

@admin.register(PlaqueColor)
class PlaqueColorAdmin(admin.ModelAdmin):
    list_display = ('name', 'hex_code')

@admin.register(TextColor)
class TextColorAdmin(admin.ModelAdmin):
    list_display = ('name', 'color')

# Inline pour ajouter plusieurs images au produit
class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 3  # Permet d'ajouter plusieurs images par défaut
    fields = ('image_url', 'alt_text', 'is_featured', 'image_preview')  # Ajout d’un aperçu d’image
    readonly_fields = ('image_preview',)  # Empêche la modification de l'aperçu
    # En ajoutant `is_featured`, tu pourras spécifier quelle image sera la principale pour ce produit.

    def image_preview(self, obj):
        """ Affiche un aperçu de l'image """
        if obj.image_url:
            return format_html('<img src="{}" width="100" height="100" style="object-fit: cover; border-radius: 5px;" />', obj.image_url.url)
        return "Aucune image"

    image_preview.short_description = "Aperçu"


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'main_image_preview', 'activity', 'text_color', 'plaque_color', 'thickness', 'material', 'width', 'height', 'is_first_vu', 'created_at', 'view_product_images')
    search_fields = ('name', 'activity__name', 'text_color__name', 'plaque_color__name')
    list_filter = ('is_first_vu', 'activity', 'text_color', 'plaque_color', 'thickness', 'material')
    list_editable = ('is_first_vu', 'text_color', 'plaque_color', 'thickness', 'material')  
    inlines = [ProductImageInline]

    def main_image_preview(self, obj):
        """ Affiche l'aperçu de l'image principale (is_featured=True) """
        featured_image = obj.images.filter(is_featured=True).first()
        if featured_image and featured_image.image_url:
            return format_html('<img src="{}" width="50" height="50" style="object-fit: cover; border-radius: 5px;" />', featured_image.image_url.url)
        return "Pas d'image"

    main_image_preview.short_description = "Image"

    def view_product_images(self, obj):
        """ Crée un lien vers la page ProductImage pour ce produit """
        # Génère l'URL pour la page d'administration des images liées au produit
        url = reverse('admin:%s_%s_changelist' % (obj._meta.app_label, 'productimage'))
        return format_html('<a href="{}?product__id__exact={}">Voir les images</a>', url, obj.id)

    view_product_images.short_description = "Voir les images"

@admin.register(ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    list_display = ('product', 'image_preview', 'alt_text', 'is_featured')  # Affiche les informations dans la liste
    list_filter = ('is_featured', 'product')  # Permet de filtrer par produit et par "is_featured"
    search_fields = ('product__name', 'alt_text')  # Recherche par nom de produit ou texte alternatif
    list_editable = ('alt_text', 'is_featured')  # Rendre ces champs modifiables directement dans la liste
    
    def image_preview(self, obj):
        """ Affiche un aperçu de l'image dans la liste """
        if obj.image_url:
            return format_html('<img src="{}" width="50" height="50" style="object-fit: cover; border-radius: 5px;" />', obj.image_url.url)
        return "Pas d'image"

    image_preview.short_description = "Aperçu"

@admin.register(PlaqueCustomization)
class PlaqueCustomizationAdmin(admin.ModelAdmin):
    list_display = ('customer', 'product', 'width', 'height', 'thickness', 'material', 'created_at')
    list_filter = ('material', 'thickness', 'plaque_color')

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('customer', 'total_price', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('customer__user__username', 'id')
