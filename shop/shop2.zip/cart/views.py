from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from .models import Cart, CartItem
from app.models import CustomizedProduct 

def add_to_cart(request, customized_product_id):
    try:
        customized_product_id_int = int(customized_product_id)
        if request.user.is_authenticated:
            customized_product = get_object_or_404(CustomizedProduct, id=customized_product_id_int)
            cart, created = Cart.objects.get_or_create(user=request.user, is_active=True)
            cart_item, item_created = CartItem.objects.get_or_create(cart=cart, customized_product=customized_product)
            if not item_created:
                cart_item.quantity += 1
                cart_item.save()
            return JsonResponse({"message": "Ajouté au panier !"})
        else:
            if "cart" not in request.session:
                request.session["cart"] = {}
            cart = request.session["cart"]
            if str(customized_product_id) in cart:
                cart[str(customized_product_id)] += 1
            else:
                cart[str(customized_product_id)] = 1
            request.session["cart"] = cart
            return JsonResponse({"message": "Ajouté au panier (session) !"})
    except ValueError:
        return JsonResponse({"message": "ID invalide"}, status=400)

def view_cart(request):
    if request.user.is_authenticated:
        try:
            cart = Cart.objects.get(user=request.user, is_active=True)
        except Cart.DoesNotExist:
            messages.info(request, "Aucun panier actif trouvé. Créez un nouveau panier.")
            cart = Cart.objects.create(user=request.user, is_active=True)
        cart_items = cart.items.all()
        total = sum(item.get_subtotal() for item in cart_items)
        return render(request, "cart.html", {"cart_items": cart_items, "total": total, "is_authenticated": True})
    else:
        cart = request.session.get("cart", {})
        cart_items = []
        total = 0
        pending_customizations = request.session.get("pending_customizations", [])
        for product_id, quantity in cart.items():
            try:
                product_id_int = int(product_id)
                customized_product = None
                for item in pending_customizations:
                    item_id = item.get("temp_id", None)
                    if item_id is not None and item_id == product_id_int:
                        customized_product = item
                        break
                if not customized_product and product_id_int < len(pending_customizations):
                    customized_product = pending_customizations[product_id_int]
                if customized_product:
                    subtotal = calculate_subtotal_temp(customized_product, quantity)
                    cart_items.append({"customized_product": customized_product, "quantity": quantity, "subtotal": subtotal})
                    total += subtotal
            except (ValueError, IndexError):
                pass
        return render(request, "cart.html", {"cart_items": cart_items, "total": total, "is_authenticated": False})

def calculate_subtotal_temp(customized_product, quantity):
    from app.models import Product, Material, MaterialThicknessPrice  # Remplacez 'your_main_app'
    base_product = get_object_or_404(Product, id=customized_product["base_product_id"])
    base_price = base_product.activity.fixed_price
    material_id = customized_product.get("material_id")
    if material_id:
        try:
            material = Material.objects.get(id=material_id)
            material_price = MaterialThicknessPrice.objects.filter(material=material).first().price_per_square_meter
            area = (base_product.width * base_product.height) / 10000
            total_price = base_price + (material_price * area)
        except (Material.DoesNotExist, MaterialThicknessPrice.DoesNotExist):
            total_price = base_price
    else:
        total_price = base_price
    return total_price * quantity