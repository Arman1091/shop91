from django.db import models
from django.contrib.auth.models import User
from app.models import CustomizedProduct  # Remplacez par le nom réel de votre app principale

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="carts")  # Changement ici
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Panier de {self.user.username} ({self.id})"

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    customized_product = models.ForeignKey(CustomizedProduct, on_delete=models.CASCADE, related_name="cart_items")  # Changement ici
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('cart', 'customized_product')

    def get_subtotal(self):
        base_price = self.customized_product.base_product.activity.fixed_price
        if self.customized_product.material and self.customized_product.thickness:
            material_price = self.customized_product.material.prices.get(
                thickness=self.customized_product.thickness
            ).price_per_square_meter
            area = (self.customized_product.base_product.width * self.customized_product.base_product.height) / 10000
            total_price = base_price + (material_price * area)
        else:
            total_price = base_price
        return total_price * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.customized_product} dans panier {self.cart.id}"