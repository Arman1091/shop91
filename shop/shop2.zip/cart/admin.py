from django.contrib import admin
from .models import Cart, CartItem

# Enregistrement de Cart
@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at', 'updated_at', 'is_active')
    list_filter = ('is_active', 'created_at', 'updated_at')
    search_fields = ('user__username',)

# Enregistrement de CartItem
@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('cart', 'customized_product', 'quantity', 'added_at', 'get_subtotal')
    list_filter = ('cart__is_active', 'added_at')
    search_fields = ('cart__user__username', 'customized_product__base_product__name')

    def get_subtotal(self, obj):
        return obj.get_subtotal()
    get_subtotal.short_description = 'Sous-total'