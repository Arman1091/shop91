from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.urls import reverse
from .models import Payment
from cart.models import Cart
import stripe
from django.conf import settings

stripe.api_key = settings.STRIPE_SECRET_KEY

def checkout(request):
    print(f"Request method: {request.method}")
    if not request.user.is_authenticated:
        print("User not authenticated")
        return redirect(f"{reverse('login')}?next={reverse('payment:checkout')}")

    try:
        customer = request.user.customer
        if not customer.is_profile_complete:
            print("Profile incomplete")
            return redirect('complete_profile')
        cart = get_object_or_404(Cart, user=request.user, is_active=True)
        cart_items = cart.items.all()
        if not cart_items:
            print("Cart empty")
            messages.error(request, "Votre panier est vide.")
            return redirect('cart:view_cart')

        total = sum(item.get_subtotal() for item in cart_items) * 100
        if total <= 0:
            print("Total <= 0")
            messages.error(request, "Le montant total doit être supérieur à 0.")
            return redirect('cart:view_cart')

        if request.method == "POST":
            print("Entering POST block")
            try:
                payment, created = Payment.objects.get_or_create(
                    cart=cart,
                    defaults={
                        "user": request.user,
                        "amount": total / 100,
                        "stripe_payment_id": f"pending_{cart.id}",
                        "status": "pending"
                    }
                )
                print(f"Payment created: {created}, Payment ID: {payment.id}")

                if not created and payment.status in ["completed", "failed"]:
                    print(f"Payment already processed: {payment.status}")
                    messages.error(request, f"Ce panier a déjà été traité (statut: {payment.status}).")
                    return redirect('cart:view_cart')

                print("Creating Stripe session...")
                session = stripe.checkout.Session.create(
                    payment_method_types=["card"],
                    line_items=[{
                        "price_data": {
                            "currency": "eur",
                            "product_data": {"name": "Achat Panier"},
                            "unit_amount": int(total),
                        },
                        "quantity": 1,
                    }],
                    mode="payment",
                    success_url=f"http://localhost:8000/payment/success/?session_id={{CHECKOUT_SESSION_ID}}&payment_id={payment.id}",
                    cancel_url="http://localhost:8000/cart/",
                )
                print(f"Session created: {session.id}")
                payment.stripe_payment_id = session.id
                payment.save()
                print(f"Redirecting to: {session.url}")
                return redirect(session.url, code=303)

            except Exception as e:
                print(f"Error in POST block: {str(e)}")
                messages.error(request, f"Erreur dans le traitement du paiement : {str(e)}")
                return redirect('cart:view_cart')

        print("Rendering checkout.html")
        return render(request, "checkout.html", {"customer": customer, "cart": cart, "total": total / 100})

    except stripe.error.StripeError as e:
        print(f"Stripe error: {str(e)}")
        messages.error(request, f"Erreur de paiement Stripe : {str(e)}")
        return redirect('cart:view_cart')
    except Exception as e:
        print(f"General error: {str(e)}")
        messages.error(request, f"Une erreur est survenue : {str(e)}")
        return redirect('cart:view_cart')

def success(request):
    session_id = request.GET.get('session_id')
    payment_id = request.GET.get('payment_id')

    if session_id and payment_id:
        try:
            payment = get_object_or_404(Payment, id=payment_id, stripe_payment_id=session_id)
            session = stripe.checkout.Session.retrieve(session_id)

            if session.payment_status == "paid":
                payment.status = "completed"
                payment.cart.is_active = False
                payment.cart.save()
                payment.save()
                messages.success(request, "Paiement effectué avec succès !")
            else:
                payment.status = "failed"
                payment.save()
                messages.error(request, "Le paiement n’a pas été complété.")
        except stripe.error.StripeError as e:
            messages.error(request, f"Erreur lors de la vérification du paiement : {str(e)}")
        except Exception as e:
            messages.error(request, f"Erreur inattendue : {str(e)}")

    return render(request, "success.html")