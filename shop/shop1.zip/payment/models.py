from django.db import models
from django.contrib.auth.models import User
from cart.models import Cart

class Payment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="payment_records")  # Changement ici
    cart = models.OneToOneField(Cart, on_delete=models.CASCADE, related_name="payment")
    stripe_payment_id = models.CharField(max_length=100, unique=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default="eur")
    status = models.CharField(max_length=20, default="pending", choices=[
        ('pending', 'En attente'),
        ('completed', 'Complété'),
        ('failed', 'Échoué'),
    ])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Paiement {self.stripe_payment_id} - {self.user.username} - {self.amount} €"